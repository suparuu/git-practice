
fetch('./data.xml')
.then(function(res){
    return res.text();
})
.then(function(data){
    console.log(data);
})


$.ajax({
    url : './data.xml',
    success : function(data){
        console.log(
            $(data).find('item')
            )
    }
})